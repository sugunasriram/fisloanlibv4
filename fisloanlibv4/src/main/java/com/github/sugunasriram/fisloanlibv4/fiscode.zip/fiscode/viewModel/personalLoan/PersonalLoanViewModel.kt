package com.github.sugunasriram.fisloanlibv4.fiscode.viewModel.personalLoan

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.navigation.NavHostController
import com.github.sugunasriram.fisloanlibv4.R
import com.github.sugunasriram.fisloanlibv4.fiscode.navigation.navigateToLoanProcessScreen
import com.github.sugunasriram.fisloanlibv4.fiscode.viewModel.BaseViewModel

class PersonalLoanViewModel : BaseViewModel() {

}
