package com.github.sugunasriram.fisloanlibv4.fiscode.navigation

object AppNavGraph {
    const val BUYERAPP = "buyer_app_graph"
    const val GRAPH_LAUNCH = "graph_launch"
}
