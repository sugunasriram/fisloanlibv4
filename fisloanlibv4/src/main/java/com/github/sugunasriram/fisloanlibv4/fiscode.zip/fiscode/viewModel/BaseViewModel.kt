package com.github.sugunasriram.fisloanlibv4.fiscode.viewModel

import androidx.lifecycle.ViewModel

open class BaseViewModel : ViewModel() {}